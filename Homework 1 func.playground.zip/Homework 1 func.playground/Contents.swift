import UIKit

//Написать функцию, которая определяет, четное число или нет.

var numberArray = [13,26,30,40,11,89,90]
 for number in numberArray{
   if number % 2 == 0{
        print(number)
    }
}
//Написать функцию, которая определяет,делится ли число без остатка на 3.
for numberTwo in numberArray{
    if numberTwo % 3 == 0{
        print("\(numberTwo) делится на 3")
    }else{
        print("\(numberTwo) делится на 3 с остатком")
    }
}
//Создать возрастающий массив из 100 чисел.
var testArray:[Int] = []
    for i in 0...99{
        testArray.append(i)
}
            print(testArray)

//Удалить из этого массива все четные числа и все числа, которые не делятся 3.
var toDelete = testArray.filter{$0 % 2 != 0 && $0 % 3 == 0}
print(toDelete)
